//
//  UserViewController.swift
//  Amazon-Ecommerce
//
//  Created by mac on 04/11/20.
//

import UIKit
import DropDown
import Toast_Swift

class UserViewController: BaseViewController {
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var logoutbtn: UIButton!
    @IBOutlet weak var main: UICollectionView!
    @IBOutlet weak var addcartView: UIButton!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var mainTableView: UITableView!
    
    var imgArr = [  UIImage(named:"image1") ,
                    UIImage(named:"image2") ,
                    UIImage(named:"image3") ,
                    UIImage(named:"image4") ,
                    UIImage(named:"image5") ]
    
    var timer = Timer()
    var counter = 0
    var searching = false
    var searchedName = [String]()
    var dropButton = DropDown()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchedName = productName
        dropButton.anchorView = searchBar
        dropButton.bottomOffset = CGPoint(x: 0, y:(dropButton.anchorView?.plainView.bounds.height)!)
        dropButton.backgroundColor = .white
        dropButton.direction = .bottom
        dropButton.selectionAction = { [unowned self] (index: Int, item: String) in
            let indexPath = NSIndexPath(row: index, section: 0)
            mainTableView.scrollToRow(at: indexPath  as IndexPath, at: .top, animated: true)
                print("Selected item: \(item) at index: \(index)") //Selected item: code at index: 0
            }
        
        self.searchBar.showsCancelButton = true
        self.searchBar.delegate = self
        logoutbtn.layer.cornerRadius = 10
        logoutbtn.layer.borderWidth = 1
        logoutbtn.layer.borderColor = UIColor.white.cgColor
        addcartView.layer.cornerRadius = 10
        addcartView.layer.borderWidth = 1
        addcartView.layer.borderColor = UIColor.white.cgColor
        pageControl.numberOfPages = imgArr.count
        pageControl.currentPage = 0
        mainTableView.register(UINib(nibName: "userTableViewCell", bundle: nil), forCellReuseIdentifier: "userTableViewCell")
        mainTableView.register(UINib(nibName: "View", bundle: nil), forHeaderFooterViewReuseIdentifier: "View")

        DispatchQueue.main.async {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.changeImage), userInfo: nil, repeats: true)
        }
    }
   
    
    func toastShow()
    {
        var style = ToastStyle()
        style.messageColor = .darkGray
        style.backgroundColor = UIColor.systemGray6
        self.view.makeToast("Product Added to Cart ! View Cart", duration: 0.5, position: .bottom, style: style)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var heightBtn: NSLayoutConstraint!
    
    @IBAction func moveBtnAction(_ sender: Any)
    {
    }
    
    
    
    
    
    
    @IBAction func logoutbtnatn(_ sender: Any) {
        let addpopup = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController") as! ViewController
              self.addChild(addpopup)
        addpopup.productImage = productImage
        addpopup.productName = productName
        addpopup.productPrice = productPrice
        addpopup.productDesc = productDesc
              addpopup.view.frame = self.view.frame
              self.view.addSubview(addpopup.view)
              addpopup.didMove(toParent: self)
    }
    
    @IBAction func addcartAtn(_ sender: Any) {
        if cartName.count != 0{
        let addpopup = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewCartViewController") as! ViewCartViewController
              self.addChild(addpopup)
            addpopup.productImage = productImage
            addpopup.productName = productName
            addpopup.productPrice = productPrice
            addpopup.productDesc = productDesc
            addpopup.cartImage = cartImage
            addpopup.cartName = cartName
            addpopup.cartPrice = cartPrice
              addpopup.view.frame = self.view.frame
              self.view.addSubview(addpopup.view)
              addpopup.didMove(toParent: self)
        }
        else{
        let alert = UIAlertController(title: "Error", message: "Please select some product", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        }
    }
   @objc func buttonTapped(sender: UIButton) {
    if sender.isSelected == false
    {
        toastShow()
        let name = productName[sender.tag]
        let price = productPrice[sender.tag]
        let image = productImage[sender.tag] 
        cartName.append(name)
        cartPrice.append(price)
        cartImage.append(image)
        print(cartName)
        print(cartPrice)
    } else
    {
        cartName.remove(at: sender.tag)
        cartPrice.remove(at: sender.tag)
        cartImage.remove(at: sender.tag)
    }
    }
   @objc func changeImage() {
    if counter < imgArr.count {
        let index = IndexPath.init(item: counter, section: 0)
        self.main.scrollToItem(at: index, at: .centeredHorizontally, animated: true)
        pageControl.currentPage = counter
        counter += 1
    } else {
        counter = 0
        let index = IndexPath.init(item: counter, section: 0)
        self.main.scrollToItem(at: index, at: .centeredHorizontally, animated: false)
        pageControl.currentPage = counter
        counter = 1
    }
    }
}
extension UserViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return imgArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        if let vc = cell.viewWithTag(111) as? UIImageView {
            vc.image = imgArr[indexPath.row]
        }
        return cell
    }
}
extension UserViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = main.frame.size
        return CGSize(width: size.width, height: size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0.0
    }
}
extension UserViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
                    return productName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = (mainTableView.dequeueReusableCell(withIdentifier: "userTableViewCell", for: indexPath) as? userTableViewCell)!
        cell.productNameLabeel.text = productName[indexPath.row]
        cell.mainImageView.image = productImage[indexPath.row]
        cell.desclbl.text = productDesc[indexPath.row]
        let text = productPrice[indexPath.row]
        cell.pricelbl.text = "\("₹")\((text as NSNumber).stringValue)"
        cell.addtocartbtn.tag = indexPath.row
        cell.addtocartbtn.addTarget(self, action: #selector(buttonTapped(sender:)), for: .touchUpInside)
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 140
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView = mainTableView.dequeueReusableHeaderFooterView(withIdentifier: "View") as! View
        headerView.sortBtn.layer.cornerRadius = 7
               return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 60
    }
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
}
extension UserViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchedName = productName.filter { $0.lowercased().prefix(searchText.count) == searchText.lowercased() }
        dropButton.dataSource = searchedName
            dropButton.show()
                searching = true
                mainTableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searching = false
               searchBar.text = ""
        searchedName = productName
           dropButton.hide()
        mainTableView.reloadData()
    }
}
