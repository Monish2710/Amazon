//
//  ViewCartViewController.swift
//  Amazon-Ecommerce
//
//  Created by mac on 07/11/20.
//

import UIKit

class ViewCartViewController: BaseViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var back: UIButton!
    @IBOutlet weak var tblView: UITableView!
    
    var final : Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(cartName)
        print(cartPrice)
        let total = cartPrice.reduce(0, +)
        final = total
        print(final!)
        print("Total",total)
        tblView.register(UINib(nibName: "cartTableViewCell", bundle: nil), forCellReuseIdentifier: "cartTableViewCell")
        tblView.register(UINib(nibName: "priceTableViewCell", bundle: nil), forCellReuseIdentifier: "priceTableViewCell")

    }
    
    @IBAction func ackatn(_ sender: Any) {
        let addpopup = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UserViewController") as! UserViewController
              self.addChild(addpopup)
            addpopup.productImage = productImage
            addpopup.productName = productName
            addpopup.productPrice = productPrice
            addpopup.productDesc = productDesc
              addpopup.view.frame = self.view.frame
              self.view.addSubview(addpopup.view)
              addpopup.didMove(toParent: self)
    }
    
    @IBAction func checkatn(_ sender: Any) {
        let addpopup = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UserViewController") as! UserViewController
              self.addChild(addpopup)
            addpopup.productImage = productImage
            addpopup.productName = productName
            addpopup.productPrice = productPrice
            addpopup.productDesc = productDesc
              addpopup.view.frame = self.view.frame
              self.view.addSubview(addpopup.view)
              addpopup.didMove(toParent: self)
    }
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 2
    }
func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
{
    if section == 0
    {
        return cartName.count
    }
    else
    {
        return 1
    }
}
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let section = indexPath.section
        if section == 0
        {
            let cell = (tblView.dequeueReusableCell(withIdentifier: "cartTableViewCell", for: indexPath) as? cartTableViewCell)!
            cell.mainImage.image = cartImage[indexPath.row]
            cell.productName.text = cartName[indexPath.row]
            let text = cartPrice[indexPath.row]
            cell.priceLabel.text = "\("₹")\((text as NSNumber).stringValue)"
            cell.selectionStyle = .none
            return cell
        }
        else
        {
            let cell = (tblView.dequeueReusableCell(withIdentifier: "priceTableViewCell", for: indexPath) as? priceTableViewCell)!
            let text = (final! as NSNumber).stringValue
            cell.totalPrice.text = "\("₹")\((text))"
            cell.priceLabel.text = "\("₹")\((text))"
            cell.selectionStyle = .none
            return cell
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 170
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 0
    }
   
}
