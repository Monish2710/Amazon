//
//  userTableViewCell.swift
//  Amazon-Ecommerce
//
//  Created by mac on 07/11/20.
//

import UIKit

class userTableViewCell: UITableViewCell {

    @IBOutlet weak var shadowImage: UIView!
    @IBOutlet weak var mainImageView: UIImageView!
    
    @IBOutlet weak var productNameLabeel: UILabel!
    
    @IBOutlet weak var desclbl: UILabel!
    
    @IBOutlet weak var pricelbl: UILabel!
    
    @IBOutlet weak var addtocartbtn: UIButton!
    
    @IBOutlet weak var addtocartlbl: UILabel!
    
    @IBOutlet weak var wishImage: UIImageView!
    @IBOutlet weak var wishlistbtn: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        wishlistbtn.isSelected = true
        addtocartbtn.isSelected = true
        addtocartbtn.layer.cornerRadius = 5
        mainImageView.layer.cornerRadius = 5
        shadowImage.layer.cornerRadius = 5
        shadowImage.layer.shadowColor = UIColor.lightGray.cgColor
        shadowImage.layer.shadowOpacity = 0.5
        shadowImage.layer.shadowOffset = .zero
        shadowImage.layer.shadowRadius = 5
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func wishAtn(_ sender: UIButton) {
        if sender.isSelected
        {
            print("Opened")
            wishlistbtn.setTitle("ADDED TO WISHLIST", for: .normal)
            wishImage.isHighlighted = true
            sender.isSelected = false
        } else
        {
            print("Closed")
            wishlistbtn.setTitle("ADD TO WISHLIST", for: .selected)
            wishImage.isHighlighted = false
            sender.isSelected = true
        }
    }
    
    @IBAction func addtocart(_ sender: UIButton) {
        if sender.isSelected
        {
            print("Opened")
            addtocartbtn.backgroundColor = UIColor(hexString: "#006F00")
            addtocartlbl.text = "ITEM ADDED TO CART"
            sender.isSelected = false
        } else
        {
            print("Closed")
            addtocartbtn.backgroundColor = UIColor(hexString: "#FF4D00")
            addtocartlbl.text = "ADD TO CART"
            sender.isSelected = true
        }
    }
    
}
extension UIColor {
    convenience init(hexString: String, alpha: CGFloat = 1.0) {
        let hexString: String = hexString.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        let scanner = Scanner(string: hexString)
        if (hexString.hasPrefix("#")) {
            scanner.scanLocation = 1
        }
        var color: UInt32 = 0
        scanner.scanHexInt32(&color)
        let mask = 0x000000FF
        let r = Int(color >> 16) & mask
        let g = Int(color >> 8) & mask
        let b = Int(color) & mask
        let red   = CGFloat(r) / 255.0
        let green = CGFloat(g) / 255.0
        let blue  = CGFloat(b) / 255.0
        self.init(red:red, green:green, blue:blue, alpha:alpha)
    }
    func toHexString() -> String {
        var r:CGFloat = 0
        var g:CGFloat = 0
        var b:CGFloat = 0
        var a:CGFloat = 0
        getRed(&r, green: &g, blue: &b, alpha: &a)
        let rgb:Int = (Int)(r*255)<<16 | (Int)(g*255)<<8 | (Int)(b*255)<<0
        return String(format:"#%06x", rgb)
    }
}
