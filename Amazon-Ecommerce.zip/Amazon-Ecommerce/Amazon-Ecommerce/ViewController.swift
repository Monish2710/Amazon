//
//  ViewController.swift
//  Amazon-Ecommerce
//
//  Created by mac on 04/11/20.
//

import UIKit
class BaseViewController: UIViewController {
    var productImage = [UIImage]()
    var productName = [String]()
    var productPrice = [Int]()
    var productDesc = [String]()
    
    var cartImage = [UIImage]()
    var cartName = [String]()
    var cartPrice = [Int]()
}
class ViewController: BaseViewController {

    @IBOutlet weak var adminlogin: UIButton!
    @IBOutlet weak var adminPassword: UITextField!
    @IBOutlet weak var adminTextField: UITextField!
    @IBOutlet weak var loginuser: UIButton!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var usernameTextfield: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        adminlogin.layer.cornerRadius = 5
        loginuser.layer.cornerRadius = 5
        adminTextField.text = "admin@mail.com"
        adminPassword.text = "123456"
        usernameTextfield.text = "user@mail.com"
        passwordTextField.text = "123456"
    }

    @IBAction func userLogin(_ sender: Any) {
        if((usernameTextfield.text == "user@mail.com")&&(passwordTextField.text == "123456"))
        {
        let addpopup = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UserViewController") as! UserViewController
              self.addChild(addpopup)
            addpopup.productImage = productImage
            addpopup.productName = productName
            addpopup.productPrice = productPrice
            addpopup.productDesc = productDesc
              addpopup.view.frame = self.view.frame
              self.view.addSubview(addpopup.view)
              addpopup.didMove(toParent: self)
        }
        else
        {
         let alert = UIAlertController(title: "Error", message: "Please enter the mail id as user@mail.com\nand password as \n123456", preferredStyle: UIAlertController.Style.alert)
                // add an action (button)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                // show the alert
                self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func adminlogin(_ sender: Any) {
        if((adminTextField.text == "admin@mail.com")&&(adminPassword.text == "123456"))
        {
        let addpopup = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AdminViewController") as! AdminViewController
//            self.present(addpopup, animated: true, completion: nil)
              self.addChild(addpopup)
            addpopup.productImage = productImage
            addpopup.productName = productName
            addpopup.productPrice = productPrice
            addpopup.productDesc = productDesc
              addpopup.view.frame = self.view.frame
              self.view.addSubview(addpopup.view)
              addpopup.didMove(toParent: self)
        }
        else
        {
         let alert = UIAlertController(title: "Error", message: "Please enter the mail id as admin@mail.com\nand password as \n123456", preferredStyle: UIAlertController.Style.alert)
                // add an action (button)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                // show the alert
                self.present(alert, animated: true, completion: nil)
        }
    }
}

