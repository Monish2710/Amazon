//
//  AdminViewController.swift
//  Amazon-Ecommerce
//
//  Created by mac on 04/11/20.
//

import UIKit
import Toast_Swift
import SimpleImageViewer

class AdminViewController: BaseViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate {

    
    
    
    
    
    
    @IBOutlet weak var loginbtn: UIButton!
    @IBOutlet weak var loginlbl: UILabel!
    @IBOutlet weak var productlbl: UILabel!
    @IBOutlet weak var productList: UIButton!
    @IBOutlet weak var mainImage: UIImageView!
    @IBOutlet weak var mainBtn: UIButton!
    @IBOutlet weak var productTextfieldName: UITextField!
    @IBOutlet weak var descriptionTextField: UITextField!
    @IBOutlet weak var priceTextfield: UITextField!
    @IBOutlet weak var mainTableView: UITableView!
    @IBOutlet weak var submitBtn: UIButton!
    var pic : UIImage?
    override func viewDidLoad() {
        super.viewDidLoad()
        [productTextfieldName, descriptionTextField,priceTextfield].forEach({$0.addTarget(self, action: #selector(editingChanged(_:)), for: .editingChanged)})
        productList.isSelected = true
        priceTextfield.delegate = self
        mainImage.layer.cornerRadius = 5
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        submitBtn.isUserInteractionEnabled = false
        submitBtn.backgroundColor = UIColor.lightGray
        loginbtn.layer.cornerRadius = 5
        loginbtn.layer.borderWidth = 1
        mainTableView.isHidden = true
        mainTableView.isHidden = true
        loginbtn.layer.borderColor = UIColor.white.cgColor
        productList.layer.cornerRadius = 5
        productList.layer.borderWidth = 1
        productList.layer.borderColor = UIColor.white.cgColor
        submitBtn.layer.cornerRadius = 5
        submitBtn.layer.borderWidth = 1
        submitBtn.layer.borderColor = UIColor.white.cgColor
        mainTableView.register(UINib(nibName: "AdminTableViewCell", bundle: nil), forCellReuseIdentifier: "AdminTableViewCell")
        
    }
    
    
    
    
    
    @IBAction func loginBtn(_ sender: Any) {
//        self.dismiss(animated: true, completion: nil)
        let addpopup = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController") as! ViewController
              self.addChild(addpopup)
        addpopup.productImage = productImage
        addpopup.productName = productName
        addpopup.productPrice = productPrice
        addpopup.productDesc = productDesc
              addpopup.view.frame = self.view.frame
              self.view.addSubview(addpopup.view)
              addpopup.didMove(toParent: self)
        mainTableView.reloadData()
    }
    
    @IBAction func productList(_ sender: UIButton)
    {
        if sender.isSelected
        {
            print("Opened")
            self.productlbl.text = "Close"
            mainTableView.isHidden = false
            mainTableView.reloadData()
            toastShow()
            loginbtn.isHidden = true
            loginlbl.isHidden = true
            sender.isSelected = false
        } else
        {
            print("Closed")
            self.view.hideAllToasts()
            mainTableView.reloadData()
            mainTableView.isHidden = true
            loginbtn.isHidden = false
            loginlbl.isHidden = false
            self.productlbl.text = "Product List"
            sender.isSelected = true
        }
    }
func toastShow()
{
    var style = ToastStyle()
    style.messageColor = .red
    style.backgroundColor = .white
    self.view.makeToast("Swipe to Delete the Product", duration: 5, position: .bottom, style: style)
}
    @IBAction func mainBtnAtn(_ sender: Any) {
        mainBtn.isSelected = true
        let image = UIImagePickerController()
        image.delegate = self
        image.sourceType = UIImagePickerController.SourceType.photoLibrary
        image.allowsEditing = false
        self.present(image, animated: true)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            mainImage.image = pickedImage
            pic = pickedImage
            }
        dismiss(animated: true, completion: nil)
    }
    @IBAction func submitAtn(_ sender: Any) {
        if (mainBtn.isSelected == true) && (productTextfieldName.text?.count != 0) && (priceTextfield.text?.count != 0) && (descriptionTextField.text?.count != 0){
        mainTableView.reloadData()
        productImage.append(pic!)
        productName.append(productTextfieldName.text!)
        let typeText: Int? = Int(priceTextfield.text!)
        productPrice.append(typeText!)
        productDesc.append(descriptionTextField.text!)
        productTextfieldName.text?.removeAll()
        priceTextfield.text?.removeAll()
        descriptionTextField.text?.removeAll()
        mainImage.image = UIImage.init(named: "photo")
        toastsucessShow()
        }
        else{
            let alert = UIAlertController(title: "Error", message: "Please ADD all Values", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        //For mobile numer validation
        if textField == priceTextfield {
            let allowedCharacters = CharacterSet(charactersIn:"0123456789")//Here change this characters based on your requirement
            let characterSet = CharacterSet(charactersIn: string)
            return allowedCharacters.isSuperset(of: characterSet)
        }
        return true
    }
    func toastsucessShow()
    {
        var style = ToastStyle()
        style.messageColor = .green
        style.backgroundColor = .white
        self.view.makeToast("Product Added Sucessfully", duration: 1, position: .bottom, style: style)
    }
    @objc func editingChanged(_ textField: UITextField)
        {
            if textField.text?.count == 1 {
                if textField.text?.first == " " {
                    textField.text = ""
                    return
                }
            }
            guard
                let pName = productTextfieldName.text, !pName.isEmpty,
                let pDes = descriptionTextField.text, !pDes.isEmpty,
                let pCost = priceTextfield.text, !pCost.isEmpty

            else {
                submitBtn.isUserInteractionEnabled = false
                submitBtn.backgroundColor = UIColor.lightGray
                return
            }
        submitBtn.isUserInteractionEnabled = true
        submitBtn.backgroundColor = UIColor.darkGray
        }
    @objc func selectImage(sender: UIButton)
    {
        let button = sender
           let indexPath = IndexPath(row:button.tag ,section:0)
           let cell = mainTableView.cellForRow(at: indexPath) as! AdminTableViewCell
        let configuration = ImageViewerConfiguration { config in
        config.imageView?.backgroundColor = UIColor.white
            config.imageView = cell.productImageView
        }
        present(ImageViewerController(configuration: configuration), animated: true)
    }
    
}
extension AdminViewController : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return productName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = (mainTableView.dequeueReusableCell(withIdentifier: "AdminTableViewCell", for: indexPath) as? AdminTableViewCell)!
        cell.productImageView.image = productImage[indexPath.row]
        cell.productName.text = productName[indexPath.row]
        cell.productDesc.text = productDesc[indexPath.row]
        let text = productPrice[indexPath.row]
        let number = (text as NSNumber).stringValue
        cell.productCost.text = "\("₹")\(number)"
        cell.imageButton.addTarget(self, action: #selector(selectImage(sender:)), for: .touchUpInside)
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 135
    }
    func tableView(_ tableView: UITableView,
       editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle
    {
        return .delete
    }
    func tableView(_ tableView: UITableView,
                     commit editingStyle: UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete{
            mainTableView.beginUpdates()
            productName.remove(at: indexPath.row)
            productImage.remove(at: indexPath.row)
            productPrice.remove(at: indexPath.row)
            productDesc.remove(at: indexPath.row)
            mainTableView.deleteRows(at: [indexPath], with: .fade)
            mainTableView.endUpdates()
        }
    }
    
}
